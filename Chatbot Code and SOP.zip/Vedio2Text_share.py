# -*- coding: utf-8 -*-
"""
Created on Sat May  2 10:57:30 2020

@author: sijwa
"""

import moviepy.editor as mp 
from pydub import AudioSegment 
from typing import List
import logging
import sys
import requests
import time
import swagger_client as cris_client
from azure.storage.blob import BlockBlobService, PublicAccess
import os
import time
import uuid
import hmac
import base64
import hashlib
import urllib
import os
import glob
from datetime import datetime, timedelta
from azure.storage import (
    AccessPolicy,
    ResourceTypes,
    AccountPermissions,
    CloudStorageAccount,
)
from azure.storage.blob import (
    BlockBlobService,
    ContainerPermissions,
    BlobPermissions,
    PublicAccess,
)

os.chdir('C:\\Term3\\Capstone\\Data\\Upload')
for file in sorted(glob.glob("*.mp4")):
    name=file
    
clip = mp.VideoFileClip(name)
## Create Video to Audio conversion and save in drive
clip.audio.write_audiofile("C:\\Term3\\Capstone\\Data\\Statistics\\Session_sil.wav")

## Need to install sox software
## Run sox on audio file to compress and remove silence disturbances
os.system('cmd /c "C:\sox1\sox.exe C:\Term3\Capstone\Data\Statistics\Session_sil.wav -r 16000 -c 1 C:\Term3\Capstone\Data\Statistics\Session_s.wav silence -l 1 0.3 1% -1 1.5 1%"')

## Delete the initial audio file
os.system('del C:\Term3\Capstone\Data\Statistics\Session_sil.wav')

account_name = '<account name>'
account_key ='<enter account key>'
block_blob_service=BlockBlobService(account_name=account_name, account_key=account_key)
container_name='<enter azure storage container name>'
SUBSCRIPTION_KEY = "<Speech to text subscription key>"
SERVICE_REGION = "centralindia"
NAME = "S2T"
DESCRIPTION = "Speech to text"
LOCALE = "en-GB"

configuration = cris_client.Configuration()
configuration.api_key['Ocp-Apim-Subscription-Key'] = SUBSCRIPTION_KEY
configuration.host = "https://{}.cris.ai".format(SERVICE_REGION)
client = cris_client.ApiClient(configuration)
transcription_api = cris_client.CustomSpeechTranscriptionsApi(api_client=client)
transcriptions: List[cris_client.Transcription] = transcription_api.get_transcriptions()

## This function upload audio file in azure blob
def upload_to_azure(path,name):
    block_blob_service.create_blob_from_path(container_name, name, path)

## Generates SAS URL for uploaded file
def get_SAS_URL(blob_name):
    url = f"https://{account_name}.blob.core.windows.net/{container_name}/{blob_name}"
    block_blob_service = BlockBlobService(account_name=account_name, account_key=account_key)
    sas_url = block_blob_service.generate_blob_shared_access_signature(container_name,blob_name,BlobPermissions.READ,datetime.utcnow() + timedelta(hours=1))
    url_with_sas = f"{url}?{sas_url}"
    return url_with_sas

## Run S2T services
def get_speech_to_text(sasurl,file):
    logging.info("Starting transcription client...")
    RECORDINGS_BLOB_URI=sasurl
    transcription_definition = cris_client.TranscriptionDefinition(
        name=NAME, description=DESCRIPTION, locale=LOCALE, recordings_url=RECORDINGS_BLOB_URI
    )

    data, status, headers = transcription_api.create_transcription_with_http_info(transcription_definition)
    transcription_location: str = headers["location"]
    created_transcription: str = transcription_location.split('/')[-1]
    logging.info("Created new transcription with id {}".format(created_transcription))
    logging.info("Checking status.")
    completed = False
    while not completed:
        running, not_started = 0, 0
        transcriptions: List[cris_client.Transcription] = transcription_api.get_transcriptions()
        for transcription in transcriptions:
            if transcription.status in ("Failed", "Succeeded"):
                if created_transcription != transcription.id:
                    continue
                completed = True
                if transcription.status == "Succeeded":
                    results_uri = transcription.results_urls["channel_0"]
                    results = requests.get(results_uri)
                    logging.info("Transcription succeeded. Results: ")
                    a = results.content.decode("utf-8").split('"Display": "')[1].split('"\r')[0]
                    block_blob_service.delete_blob(container_name, file)
                else:
                    logging.info("Transcription failed :{}.".format(transcription.status_message))
                    break
            elif transcription.status == "Running":
                running += 1
            elif transcription.status == "NotStarted":
                not_started += 1
        logging.info("Transcriptions status: "
                     "completed (this transcription): {}, {} running, {} not started yet".format(
                         completed, running, not_started))
    return a



os.chdir('C:\\Term3\\Capstone\\Data\\Statistics')
for file in sorted(glob.glob("*.wav")):
    path=os.getcwd()+'\\'+file

upload_to_azure(path,file)
print("file uploaded to Azure")
url_with_sas=get_SAS_URL(file)

a2=get_speech_to_text(url_with_sas,file)
print("text conversion finished")

os.chdir('C:\\Term3\\Capstone\\Data\\Text')
name1=name.split('.')[0]+'.txt'
text_file = open(name1, "w")
text_file.write(a2)
text_file.close()
          